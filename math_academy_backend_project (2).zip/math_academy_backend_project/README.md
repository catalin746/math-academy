# Matematică pe clase - variantă cu backend și bază de date

Acest pachet transformă site-ul într-o aplicație locală cu backend real:

- autentificare pe server
- bază de date SQLite
- conturi persistente
- acces de pe mai multe dispozitive din aceeași rețea, dacă pornești serverul pe un IP accesibil
- salvare pe server pentru grupe, înscrieri, teste, teme și progresul ultimelor lecții

## Structură

- `server.py` - backend FastAPI + SQLite
- `static/index.html` - site-ul modificat să folosească backendul
- `data/math_academy.db` - baza de date, creată automat la prima rulare
- `requirements.txt` - dependențe Python
- `start_server.bat` - pornire rapidă pe Windows
- `start_server.sh` - pornire rapidă pe Linux/macOS

## Pornire pe Windows

1. Instalează Python 3.10+.
2. Deschide folderul proiectului.
3. Rulează `start_server.bat`.
4. Deschide în browser: `http://127.0.0.1:8000`

## Pornire manuală

```bash
python -m pip install -r requirements.txt
python -m uvicorn server:app --host 127.0.0.1 --port 8000
```

Apoi deschizi:

```text
http://127.0.0.1:8000
```

## Conturi demo

- profesor_demo / 1234
- elev_demo / 1234

## Ce este salvat acum în baza de date

- utilizatori
- sesiuni de login
- grupe și coduri de acces
- înscrieri elevi în grupe
- vizite pe lecții
- teste, întrebări și trimiteri
- teme și predări
- starea ultimei lecții pentru fiecare utilizator

## Observații

- secțiunea de examene și olimpiade rămâne în frontend și funcționează ca înainte
- secțiunea Mesaje a rămas pregătită pentru extindere ulterioară
- baza de date este creată automat la prima pornire
